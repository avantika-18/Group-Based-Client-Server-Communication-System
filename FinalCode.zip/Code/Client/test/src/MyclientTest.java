/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package src;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nauma
 */
public class MyclientTest {
    
    public MyclientTest() {
    }
    
    @Test
    public void TestClientID(){
        System.out.println("* JUnit4Test: test Client - checkExpectedID()");
    assertEquals("ClientID\u0023", ("ClientID\u0023"));
}
   
   
    
        
    }
    
