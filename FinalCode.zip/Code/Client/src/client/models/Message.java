package src.client.models;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDateTime;

public class Message implements Serializable { // responsible for sending the objects through socket
    Client fromClient;
    Client toClient; // null means broadcasted to everyone
    String content;
    LocalDateTime timestamp; // tracks when message is swent

    public Message(Client fromClient, Client toClient, String content) { // Creates the message
        this.fromClient = fromClient; // from one client that sends the message
        this.toClient = toClient; // tracks the client the message is sent to 
        this.content = content; // message content
        this.timestamp = LocalDateTime.now(); // tracks the current time of message sent
    }

    @Override
    public String toString() {
        return "from " + this.fromClient.getClientId() + " to " +
                (this.toClient == null ? "all" : this.toClient.getClientId()) + ": " +
                this.content + ", at " + this.timestamp.toString(); // Returns the message with timestamp
    }


    public void sendMessage() throws IOException {
        if (this.toClient != null) { 
            new DataOutputStream(this.toClient.getSocket().getOutputStream()).writeUTF(this.toString());
        }
    }

    public boolean isBroadcast() {
        return this.toClient == null; // return true, therefore broadcast messaging
    }
}
