package server;

import server.models.Client;
import server.models.Message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ConnectionSingleton {
    private static ConnectionSingleton instance;
    private Client coordinator; // indicates which client is the coordinator
    private final Map<String, Client> clientColl;
    private final List<Message> messages; 

    private ConnectionSingleton() {
        this.coordinator = null; // no coordinator when server starts running
        this.clientColl = new HashMap<>(); 
        this.messages = new ArrayList<>(); // blank due to no instantiation of clients and messages
    }

    public String getCoordinatorId(){
        if(this.coordinator == null) {
            return "N/A";         // when null, it will return N/A, which means unavailable
        } else {
            return this.coordinator.getClientId();
        }
      //  return (this.coordinator == null? "N/A": this.coordinator.getClientId());
    }
    public boolean isClientExisting(String clientId) { // checks whether the client is still in the server
        return this.clientColl.containsKey(clientId); 
    }

    public List<String> getAllClientIds() { // displays list of all existing client IDs
        return new ArrayList<String>(this.clientColl.keySet());
    }

    public boolean hasClient() {
        return !this.clientColl.isEmpty(); // if return true, it has clients in the server
    }

    public void addClient(String clientId, Client client) {
        if (this.clientColl.isEmpty()) { // if the client list is empty, 
            this.coordinator = client; // first client becomes coordinator
        }
        this.clientColl.put(clientId, client); // adds the client in the server
    }

    public Client getClient(String clientId) {
        return this.clientColl.get(clientId);
    }

    public void removeClient(String clientId) {
        this.clientColl.remove(clientId); // removes the client ID from server

        if (this.clientColl.isEmpty()) {
            this.coordinator = null; // no one is coordinator
        } else if (coordinator.getClientId().equals(clientId)) {
            coordinator = this.clientColl.values().stream().findAny().get(); // allocates coordinator to other client when current coordinator leaves
        }
    }

    public List<Message> getAllBroadcastMessages() { // displays all messages
        return this.messages.stream().filter(Message::isBroadcast).collect(Collectors.toList()); // filters message to isBroadcast on whether it is broadcast message or not
    }

    public void addMessage(Message message) {
        this.messages.add(message);
    }

    public static ConnectionSingleton getInstance() {
        if (instance == null) {
            instance = new ConnectionSingleton();
        } // gets single instance of Singleton
        return instance;
    }
}
