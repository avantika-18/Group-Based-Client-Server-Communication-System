package server.observer.listeners;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClientLeaveListener extends EventListener {
    public ClientLeaveListener(String clientId) {
        super(clientId, "leave");
    }

    @Override
    public void handleEvent(String data) throws IOException {
        new DataOutputStream(((Socket) this.connectionSingleton.getClient(this.clientId).getSocket()).getOutputStream()) // gets socket to get actual socket
                .writeUTF("12;;" + data); // sends leaving signal to client

    }
}
