package server.observer.listeners;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClientJoinListener extends EventListener {

    public ClientJoinListener(String clientId) {
        super(clientId, "join");
    }

    @Override
    public void handleEvent(String data) throws IOException {
        new DataOutputStream(((Socket) this.connectionSingleton.getClient(this.clientId).getSocket()).getOutputStream())
                .writeUTF("11;;" + data); // sends joining signal to client
    }
}
