package server;

public class UIFacade {

    private View swingView;

    public UIFacade() {
        swingView = new View();
        swingView.setVisible(true);
    }

    public void setStatusForSuccessfulConnection() {
        swingView.getjStatus().setText("Server has started.");
        swingView.getjStatus1().setText("IP Address: 127.0.0.1");
    }

    public void addContentToMsgBox(String data) {
        swingView.getMsgBox().append(data);
    }
}
