package server.models;

import server.ConnectionSingleton;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.net.Socket;
import java.time.LocalDateTime;

public class Message implements Serializable {
    Client fromClient;
    Client toClient; // null means broadcasted to everyone
    String content;
    LocalDateTime timestamp;

    public Message(Client fromClient, Client toClient, String content) {
        this.fromClient = fromClient;
        this.toClient = toClient;
        this.content = content;
        this.timestamp = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "from_to_timestamp: " + this.fromClient.getClientId() + "_" +
                (this.toClient == null ? "all" : this.toClient.getClientId()) + "_" +
                this.content + "_" + this.timestamp.toString();
    }


    public void sendMessage() throws IOException {
        System.out.println(this);
        if (this.toClient != null) {
            new DataOutputStream(this.toClient.getSocket().getOutputStream()).writeUTF(this.toString());
        }
    }

    public boolean isBroadcast() {
        return this.toClient == null;
    }
}
