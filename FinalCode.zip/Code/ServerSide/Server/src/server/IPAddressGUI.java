/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import java.net.InetAddress;
import javax.swing.*;

public class IPAddressGUI extends JFrame {

    private JLabel ipAddressLabel;

    public IPAddressGUI() {
        super("IP Address GUI");

        ipAddressLabel = new JLabel();
        ipAddressLabel.setHorizontalAlignment(SwingConstants.CENTER);
        ipAddressLabel.setVerticalAlignment(SwingConstants.CENTER);

        try {
            InetAddress localAddress = InetAddress.getLocalHost();
            ipAddressLabel.setText("IP Address: " + localAddress.getHostAddress());
        } catch (Exception ex) {
            ipAddressLabel.setText("Error getting IP address: " + ex.getMessage());
        }

        add(ipAddressLabel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setVisible(true);
    }

    public static void main(String[] args) {
        new IPAddressGUI();
    }

}

